#!/usr/bin/python
import sys
sys.path.append('/Users/weihan/pyscript')

import PDB
import readTop
import top_db
import helper

fnm=helper.arg_w_opt(sys.argv[1:],'-f')

tops= readTop.load_tops_rtf(fnm)

resnms=[i.resnm for i in tops]
#print resnms


tops[resnms.index('RC')].show()

