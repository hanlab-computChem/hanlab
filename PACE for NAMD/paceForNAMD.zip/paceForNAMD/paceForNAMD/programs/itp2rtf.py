import sys
from helper import *
from readTop import *
from readFF import *

#=======Main========
opt=sys.argv[1:]

if opt==[]:
 print 'Option		Remark'
 print '-top		GMX itp topology:.itp .top'
 print '-ff		GMX force field file for the loaded topology: .itp'
 print '-refff		GMX force field for generating pair interactions'
 print '-prm		output prm file for NAMD'
 print '-scale14	Scaling factor for 14 pair interaction (0.125)'
 sys.exit()

topfile= arg_w_opt(opt,'-top')
fffile=arg_w_opt(opt,'-ff')
refff = arg_w_opt(opt,'-refff',None)
outfile = arg_w_opt(opt,'-prm')
SCNB = arg_w_opt(opt,'-scale14','0.125')


res_tops=load_tops_gmx(topfile)

print '*Convert from',sys.argv[1],'by itp2rtf.py'
print '13   1'
atom_list, mass_list = summary_atom_in_top(res_tops)
k=1
for i,j in zip(atom_list, mass_list):
 print 'MASS      ',k,i,' %.3f  '%(j),i[0]
 k+=1
print


print 'DEFA FIRS NONE LAST NONE'
print 'AUTO  NONE'


for i in res_tops:
# print i.resnm
 i.show()
 print
if refff!=None:
 ffref= FFdata(refff,False, None, True, 1.0, None, [1])
else:
 ffref=None

ff1=FFdata(fffile, False, None, True, float(SCNB), ffref)
ff=FFdata(None,True,res_tops)

ff1.append(ff)
#ff = FFdata(sys.argv[1])
ff1.show('Extracted from '+fffile+' and '+topfile, outfile)
#print ff.dihe_params
