import sys
from PDB import *
from geom import *

system=PDBdata(sys.argv[1])
a_list=[]
for i in range(2, len(sys.argv)):
 a_list.append(sys.argv[i])

s_xp=[]
xp=system.xp
atomnms=system.atomnms
for i,j in zip(atomnms, xp):
 if len(a_list)==0:
  s_xp.append(j)
 elif i in a_list:
  s_xp.append(j)

if len(s_xp)==0:
 print 'Nothing has been selected'
 quit()

maxb, minb =find_max_min (s_xp)
print '	x	y	z'
print 'min	',
for i in minb: print '%.2f	'%(i),
print
print 'max	',
for i in maxb: print '%.2f	'%(i),
print
