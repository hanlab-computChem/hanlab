import sys

class MODpair:
 def __init__(self, fnm):
  f=open(fnm,'r')
  self.__modpff=[]
  for rl in f:
   if 'MODP' in rl: break

  for rl in f:
   if '!' in rl:
    rl=rl[:rl.index('!')] 
   else:
    rl=rl[:-1]

   srl=rl.split()
   if len(rl)==0: continue
   #in charmm format
   self.__modpff.append([float(srl[0]), float(srl[1])])

  f.close()


 def get_modp(self):
  return self.__modpff

