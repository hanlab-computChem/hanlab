### Creating global elastic network (EN) bonds for open and closed structures of KcsA
python martini.py -f 3f7v.pdb -o system.top -x cg.pdb -dssp dssp -p backbone -ff elnedyn22
mv Protein_A.itp open_Protein_A.itp

python martini.py -f 1k4c.pdb -o system.top -x cg.pdb -dssp dssp -p backbone -ff elnedyn22
mv Protein_A.itp closed_Protein_A.itp


### Obtaining appropriate EN bonds for KcsA by comparing the open and closed structures of KcsA and select the pairs whose distance varies by over 10% between the two structures
python get_ENs.py open_Protein_A.itp closed_Protein_A.itp > new_ENs.xvg
