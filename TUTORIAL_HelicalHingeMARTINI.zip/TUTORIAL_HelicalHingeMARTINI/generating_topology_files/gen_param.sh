### Creating standard MARTINI topology files
python martini.py -f 3f7v.pdb -o system.top -x cg.pdb -dssp dssp -p backbone -ff martini22


### Creating a file containing additional parameter set for TM1 helix of chain A of KcsA
python hinge.py  3f7v.pdb  Protein_A.itp  A  30  52  >  chainA_TM1_param.itp


### Creating a file containing additional parameter set for P-helix of chain A of KcsA
python hinge.py  3f7v.pdb  Protein_A.itp  A  62  74  >  chainA_P-helix_param.itp


### Creating a file containing additional parameter set for TM2 of chain A of KcsA
python hinge.py  3f7v.pdb  Protein_A.itp  A  86  116  >  chainA_TM2_param.itp


### Combination new parameter sets of all TM helices of chain A of KcsA
cat chainA_TM1_param.itp chainA_P-helix_param.itp chainA_TM2_param.itp > chainA_param.itp 


### To merge chainA_param.itp into the standard topology Protein_A.itp
python  insert_param.py  Protein_A.itp  chainA_param.itp
