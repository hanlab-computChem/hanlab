import mdtraj as md
import numpy as np
import sys
import itertools
import networkutil

def getindex(pdb,resnum):
	top = md.load(pdb).topology
	index = []
	resindex = [res.index for res in top.residues]
	for _r in resindex:
  		atomid = [atom.index for atom in top.residue(_r).atoms]
   		index.append(atomid)
   	index = np.array(index).reshape(len(index)/resnum,resnum)
   	return index

def contact(dist):
	d0 = 0.5
	cont = dist <= d0
	cont = cont+0
	return cont

def distance(pdb,traj,resnum):
	xtcfile = md.load(traj,top=pdb)
	index = getindex(pdb,resnum)
	data = []
	for i in range(len(index)):
		dataone = []
		for j in range(len(index)):
			pairs = []
			for _r in index[i]:
				for _rr in index[j]:
					pair = list(itertools.product(_r, _rr))
					pairs += pair
			dist = md.compute_distances(xtcfile,pairs)
			dmin = np.min(dist,axis=1)
			upper = dmin < 0.8 #reverse
			upper = upper-1

			lower = np.sum(contact(dist),axis=1)
			sum = upper + lower
			dataone.append(sum)
		data.append(dataone)
	return data

def find_patch(_conn):
 	_re = networkutil.strong_connected_components(_conn)
 	print 'nclu: %s'%len(_re)
 	for _i in _re: print len(_i),_i

#### MAIN #####
pdb = sys.argv[1]
traj = sys.argv[2]
n_mono = 18 ### number of monomer in system
resnum = 6 ### number of residue in one peptide chain
cutoff = 3  ### cutoff of number of contacts

contactmat = np.zeros((n_mono,n_mono),dtype=int)
distdata = distance(pdb,traj,resnum)

frame = len(distdata[0][0])

for fr in range(frame):
	for n in range(n_mono):
		for _n in range(n_mono):
			if distdata[n][_n][fr] >= cutoff:
				contactmat[n][_n] = 1
			if int(distdata[n][_n][fr]) == -1:
				contactmat[n][_n] = 0

	cluster = []
	for c in range(n_mono):
		clu = []
		for _c in range(n_mono):
			if contactmat[c][_c] == 1:
				clu.append(_c)
		#print clu
		cluster.append(clu)
	find_patch(cluster)




