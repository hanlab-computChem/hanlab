import numpy as np
from itertools import product
import sys
import mdtraj as md
import find_buied_strand 


pdb = sys.argv[1]
traj = sys.argv[2]
clu_num = int(sys.argv[3])
n_mono = int(sys.argv[4])

xtcfile = md.load(traj,top=pdb)
_sele_atom = xtcfile.topology.select('protein and backbone and name CA')
_sele_atom = _sele_atom.reshape(n_mono, int(len(_sele_atom)/n_mono))
dssp = md.compute_dssp(xtcfile, simplified=True)

phe_num = xtcfile.topology.select('protein and resname PHE and (name CA or name CB)')
phe_num = phe_num.reshape(int(len(phe_num)/4), 4)
phe = np.zeros(phe_num.shape)
phe[:,0] = phe_num[:,1]
phe[:,1] = phe_num[:,0]
phe[:,2:] = phe_num[:,2:]

phe_dih = md.compute_dihedrals(xtcfile, phe)
phe_dih = np.abs(phe_dih/np.pi*180)
phe_dih = (phe_dih >= 120)
phe_dih = (phe_dih + 0)

frame = np.loadtxt('frame%d.xvg'%clu_num, dtype=int)
clu = np.loadtxt('clu%d.xvg'%clu_num, dtype=int)

if len(frame.shape) == 0:
    frame = np.array([frame])
    clu = np.array([clu])


mat = np.zeros((len(frame), 2), dtype=int)

fw = open('%d-connectivity.xvg'%(clu_num), 'w')
for _fr,fr in enumerate(frame):
   _dssp = dssp[fr].reshape(n_mono,len(dssp[fr])/n_mono)
   _beta = []
   for _c,c in enumerate(clu[_fr]):
           _idx_beta = np.where(_dssp[c] == 'E')[0]
           _diff_beta = np.diff(_idx_beta)
           _judge_diff = np.where(_diff_beta == 1)[0]
           if len(_judge_diff) >= 1:
               _beta.append(c)

   fw.write('----%d----\n'%(_fr))
   if len(_beta) < 2:
     fw.write('[]\n')     

   if len(_beta) >= 2:
     _del_pep = []
     _beta_conn = []

     for _b,_be in enumerate(_beta):
         _beta_co = []
         for _bb,_bbe in enumerate(_beta):
            if _be != _bbe:
               _pair = list(product(_sele_atom[_be], _sele_atom[_bbe]))
               _dist_beta = md.compute_distances(xtcfile[fr], np.array(_pair))
               _idx_dist = np.where(_dist_beta <= 0.6)[0]
               if len(_idx_dist) >= 1:
                   _beta_co.append(_bb)
         if _beta_co == []:
               _del_pep.append(_b)
         _beta_conn.append(_beta_co)
     
     fw.write('%s\n'%_beta_conn)

     _idx_0 = np.where(phe_dih[fr][clu[_fr]] == 0)[0]
     _phe_beta_0 = np.intersect1d(np.array(_beta), clu[_fr][_idx_0])

     _is_nf = np.zeros(len(_beta),dtype=int)
     for _p,_ph in enumerate(_phe_beta_0):
         _idx_nf = np.where(_beta == _ph)[0]
         _is_nf[_idx_nf] = 1
      
     _is_nf_del = []
     _beta_conn_del = []
     if _del_pep != []:
         for _nf in range(len(_is_nf)):
             if _nf not in _del_pep:
                  _is_nf_del.append(_is_nf[_nf])
             
             if _beta_conn[_nf] != []:
                for _b,_be in enumerate(_beta_conn[_nf]):
                
                  _count = 0
                  for _del in _del_pep:
                      if _be > _del:
                          _count += 1
                  _beta_conn[_nf][_b] = _be - _count
                _beta_conn_del.append(_beta_conn[_nf])
         _beta_conn = _beta_conn_del
         _is_nf = np.array(_is_nf_del)

     
     _max_depth = find_buied_strand.find_buried(_beta_conn, _is_nf.tolist())

     mat[_fr,0] = len(_is_nf)
     mat[_fr,1] = _max_depth

fw.close()
np.savetxt('%d_beta_depth.xvg'%(clu_num), mat, fmt='%d')

