import sys
import numpy
import numpy.linalg
import math

def combSum(_l,_num_left ,_num_right):

 if _num_left<0: return
 if _num_left==0: 
  _l.append([_i for _i in _num_right[1:]])
  return
 _max = _num_right[-1]
 
 for _ci in range(1,_max+1):
   _t_r = [_i for _i in _num_right]
   combSum(_l,_num_left- _ci, _t_r+[_ci] )

def factor(N):
 _v =1
 for i in range(1,N+1):
  _v*=i
 return _v

def H_f(kn_list, v_v0=1.0):
 _v = 1.0
 for i in range(len(kn_list)):
  _v*=(1.0/float(factor(kn_list[i])))
 return _v*v_v0**(sum(kn_list))

#MAIN
def comb_main(nchain, Par4):
#construct systems of linear equations
#Par4 = [[[[1,4]],0.020441],[[[1,1],[3,1]],0.398125],[[[2,2]],0.239084],[[[1,2],[2,1]],0.198686],[[[4,1]],0.135330]] ## step1
 all_par = [[nchain, Par4]]
 _tot_eq = 0
 _clu_size = []
 for _i in all_par:
  _da = _i[1]
  _n = len(_da)
  if _n<2:
   print 'For N=',_i[0],'there are fewer than 2 condistions!'
   sys.exit()

  _tot_eq+=(_n-1)

  for _j in _da:
   for _k in _j[0]:
    if _k[0] not in _clu_size:
     _clu_size.append(_k[0])

 _clu_size.sort()

 ###print 'There are',_tot_eq,'independent equations'
 ###print 'found clusters with sizes',_clu_size

 if _clu_size[0]==1:
 # q_1 =1 so no need to solve its partition function
 # q_n_r = q_n/q_1^n
  _a = _clu_size[1:]
  _clu_size = _a

 _eq_all_par=[]

 for _i in all_par:
  _da = _i[1]
  _n = len(_da)
 
 # _eq_last = _da[_n-1]
  _eq_all=[]
  for _kk in range(_n):
   _eq = _da[_kk]
   
   _tN=0
   _k_list = []
   _coeff = [0.0]*len(_clu_size)
   for _jj in _eq[0]:
    _cls = _jj[0]
    _cls_cnt = _jj[1]
    _tN+=_cls*_cls_cnt
    _k_list.append(_cls_cnt)
    if _cls!=1:
     _idx = _clu_size.index(_cls)
     _coeff[_idx] = float(_cls_cnt)

   if _tN!= _i[0]:
    print 'in',_coeff,'total number of monomers is not correct!'
    sys.exit()
#  print _k_list
   _P = _eq[1]
   _eq_all.append([_coeff, math.log(_P)-math.log(H_f(_k_list))])
   ###print _eq_all[-1]
  
  _coeff_last = _eq_all[-1][0]
 
  _f_last = _eq_all[-1][1]  
  for _kk in range(_n-1):
   _eq_all_par.append([[__i-__j for __i, __j in zip(_eq_all[_kk][0],_coeff_last)], _eq_all[_kk][1] - _f_last])
# print '--'
#_nl = []
#combSum(_nl, 8,[8])

#for i in _nl: print i


#solve least square problem
 _M = len(_eq_all_par)
 _N = len(_clu_size)
 _A = numpy.zeros((_M,_N),dtype=numpy.float64)
 _B = numpy.zeros(_M, dtype=numpy.float64)
 for _i in range(_M):
  for _j in range(_N):
   _A[_i,_j]= _eq_all_par[_i][0][_j]
  
  _B[_i] = _eq_all_par[_i][1]

 ###print 'Matrix constructed'
 ###print _A
 ###print 'Data to fit'
 ###print _B

 ###print 'Solution'
 _X = numpy.linalg.lstsq(_A,_B)

 _label = numpy.allclose(_A.dot(_X[0]),_B)
 _len_A = len(_A)
 diff = _A.dot(_X[0])-_B

 ###print _X[0]
 return _clu_size,_X[0],_label,_len_A,diff

