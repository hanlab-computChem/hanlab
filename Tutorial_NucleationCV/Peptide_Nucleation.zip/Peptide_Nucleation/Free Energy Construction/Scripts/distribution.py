import numpy as np
import sys


clu_num = int(sys.argv[1])

n_mono = 18 ### peptide number in system

frame = np.loadtxt('frame%d.xvg'%clu_num, dtype=int)

weight = np.loadtxt('step2-weights.dat', dtype=float)

data = np.loadtxt('%d_beta_depth.xvg'%clu_num, dtype=int)

mat = np.zeros((n_mono, n_mono))

for _fr,fr in enumerate(frame):
   if data[_fr][1] != -1:
       if data[_fr][0] == 0 and data[_fr][1] == 0:
            mat[0,0] += 1*weight[fr]
       else:
            mat[data[_fr][0]-(data[_fr][1]+1), data[_fr][1]] += 1*weight[fr]


mat = mat/np.sum(mat)


fw = open('prob-beta-depth-%d.xvg'%clu_num, 'w')
for i in range(len(mat)):
    for j in range(len(mat[0])):
        if i >= 1:
         fw.write('%d %d %f\n'%(i+1,j,mat[i,j]))
        else:
         fw.write('%d %d %f\n'%(i,j,mat[i,j]))

fw.close()
                     

