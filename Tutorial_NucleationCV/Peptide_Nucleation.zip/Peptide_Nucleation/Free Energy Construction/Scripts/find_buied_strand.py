import numpy as np
import sys





def find_buried(conn, _is_nf):

## conn [[],[]]
# conn[0][0]  

 _max_depth = 0

 _n = len(conn)
 _is_edge = np.zeros(_n, dtype=np.int32)
 _mark = np.zeros(_n, dtype=np.int32)

 if len(_is_nf)!=_n:
  print 'Error: incorrect formatofinput data'
  sys.exit()


 for _i in xrange(_n):
  if len(conn[_i])==1: _is_edge[_i]=1


 _que = np.zeros(_n*2, dtype= np.int32)
 _que_d = np.zeros(_n*2, dtype = np.int32)

 for _i in xrange(_n):
  if _is_nf[_i]==0: continue
  _mark[:]=0
  _h=0
  _r=0

 

  _r+=1
  _que[_h] = _i
  _que_d[_h] = 1
  _d = -1
  _mark[_i]=1

  while _h<_r:

   _ci = _que[_h]

   _di = _que_d[_h]

   _h+=1

   if _is_edge[_ci] ==1:
    _d = _di
    break

   for _k in conn[_ci]:
    if _mark[_k]==1: continue
    _mark[_k]=1
    _que[_r] = _k
    _que_d[_r] = _di+1
    _r+=1


  if _d==-1:
   _max_depth = -1
   print 'Error: incorrect connectivity for',_i


  if _d> _max_depth:
   _max_depth = _d



 return _max_depth



#debug

conn=[[1],[0,2],[1,3],[2,4],[3,5],[4,6],[5,7],[6,8],[7],[10],[9]]

print find_buried(conn, [0,0,0,0,0,0,0,0,0,0,0])





