import numpy as np
import sys

free = sys.argv[1] ### free energy file
fe = []
with open(free) as f:
   for lf in f:
    if 'oligomer' not in lf:
      _lf = lf.split(':')
      fe.append(float(_lf[1]))

prob = sys.argv[2] ### probability file

data = np.loadtxt(prob)

_idx_zero = np.where(data[:,-1] == 0.0)[0]

data[_idx_zero,-1] = 1e-50

clu = int(sys.argv[3]) ### number of oligomer size

data[:,-1] = -np.log(data[:,-1])+fe[clu-1]

np.savetxt('f_n_b_m_%d.xvg'%clu, data, fmt='%f')

