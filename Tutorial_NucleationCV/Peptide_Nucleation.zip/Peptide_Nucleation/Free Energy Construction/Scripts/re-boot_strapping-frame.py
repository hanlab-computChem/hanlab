from __future__ import division
import numpy as np
import sys
import os
import combSum
import math

_ntraj = 1
_nboot = int(sys.argv[1])
_skip = 1
_stop = float(sys.argv[2])


### the directory
_out_dir = ''

### weight of metadynamics simulation
weight = np.loadtxt(_out_dir+'weights.dat',dtype=np.float32) 

### use different steps to calculate error bar
_nchain =18
_par_type, _par_num, _par_label = [],[],[]
_frame_list = 0
_time = 0

### the file format of 03-contact-p2/
_tot= 5000000 ## ps
_nstep = 100
_part = _tot//_nstep

_all = []

### result of cluster
with open(_out_dir+'clu_result.xvg') as f:
  for line in f:
    if 'nclu' in line:
      _frame_list += 1
      _comp = []
    if 'nclu' not in line:
      _comp.append(int(line.split()[0]))

      if sum(_comp) == _nchain:
        _all.append(_comp)

for _fr, _c in enumerate(_all):
  _out = []
  ### generate the type of oligomer
  _comp_arr = np.array(_c)
  _comp_arr_u = np.unique(_comp_arr)
  _num_comp_itm = np.zeros(len(_comp_arr_u))

  for _ee,_rr in enumerate(_comp_arr_u):
    _index = np.where(_comp_arr == _rr)[0]

    _num_comp_itm[_ee] = len(_index)
    _out.append([_rr,len(_index)])

  if _out not in _par_type:
    _par_type.append(_out)
    _par_num.append(1.*weight[_fr])
  else:
    _id_out = _par_type.index(_out)
    _par_num[_id_out] += 1.*weight[_fr]
  _pid = _par_type.index(_out)
  _par_label.append(_pid)

#### count frame of different combination ####
_frcom = [0]*(len(_par_type))
for _p,_pa in enumerate(_par_type):
  _frcom[_p] += len(np.where(np.array(_par_label) == _p)[0])

_max,_temp = 0, []
for _l,_m in enumerate(_par_type):
  _temp.append(max([i[0] for i in _m]))
  if max(_temp) >_max:
    _max = max(_temp)
#print '_max',_max

_boot_size = _frame_list *0.3

try:
  os.mkdir(_out_dir+'boost/frame/boot%d-stop%s/'%(_nboot,_stop))
except OSError:
  pass
_dir = _out_dir+'boost/frame/boot%d-stop%s/'%(_nboot,_stop)

fo_distri = open(_dir+'%s-oligo-distribution.xvg'%(_nchain),'w')

### Write the oligomer distribution of all frames

_full = [i+1 for i in range(_max)]
_prop,_oligo = np.zeros(_max,dtype=np.float32), np.zeros(_max,dtype=np.float32)
_label = np.zeros(_frame_list, dtype=np.int)

for _e,_r in enumerate(_par_label):
  for _l,_m in enumerate(_par_type[_r]):
    _id = _full.index(_m[0])
    _oligo[_id] += _m[0] *_m[1] * weight[_e]

for _l,_m in enumerate(_full):
  _prop[_l] = _oligo[_l]/np.sum(weight)/_nchain
  fo_distri.write('%d : %s\n'%(_m,_prop[_l]))

def _cal_par_prop(_sele_label, _par_label, _par_type, max=30):
  _olig_num = np.zeros(max, dtype=np.float64)
  for _e  in _sele_label:
    for _l in _par_type[_par_label[_e]]:
      _index = range(1,max+1).index(_l[0])
      _olig_num[_index] += _l[0]*_l[1]*weight[_e]
  return _olig_num

def gen_tot(sample,_par_type):
  _tot,_num = [],[0 for i in _par_type]

  for i in sample:
    _num[i] += 1
  for _e,_par in enumerate(_par_type):
    _tot.append([_par, _num[_e]/len(sample)])
  _tot.sort(key=lambda _tot: _tot[1], reverse=True)
  return _tot


def solve_linear_eq(_eq, _nchain=18):
  _eq.sort(key=lambda _eq:_eq[1],reverse=False)
  try:
    _cluster, _relative_free, _label,_len_A,diff = combSum.comb_main(_nchain, _eq)
    _output = sum([abs(i) for i in diff])/len(_eq)
    return _relative_free,_output,_cluster
  except ValueError:
    return [],0,[]

### Boot Strapping ##
_boot_size = int(_frame_list *0.3)
_rela_free,_prop, _e = [],[],0
_out_boot = [[] for i in range(len(_par_type))]
_out_boot_weight = [[] for i in range(len(_par_type))]

while _e < _nboot:
  _sample = np.random.choice(range(len(_par_label)),size=_boot_size)

  ## calculate oligomer distribution
  sumweight = np.sum(weight[_sample])
  _oligo = _cal_par_prop(_sample, _par_label, _par_type,max=_max)
  _prop.append(_oligo/sumweight/_nchain)
  ## 
  for _p,_par in enumerate(_par_type):
    sample = np.random.choice(range(len(_par_label)),size=_boot_size)
    _sumweight = np.sum(weight[sample])
    _pos = np.where(np.array(_par_label)[sample]==_p)[0]
    _out_boot[_p].append(len(_pos)/np.float(_boot_size))
    #_out_boot_weight[_p].append(np.sum(weight[sample][_pos])/_sumweight)
    _out_boot_weight[_p].append(np.sum(weight[sample][_pos]))
  _e += 1

##########
_mean_out, _mean_out_weight, _std_out, _use_comb, _use_comb_weight = [],[],[],[],[]
for i in range(len(_par_type)):
  _mean_out.append(np.array(_out_boot[i]).mean())
  _mean_out_weight.append(np.array(_out_boot_weight[i]).mean())
  _std_out.append(np.array(_out_boot[i]).std())
  _use_comb.append([_par_type[i],_mean_out[i]])
  _use_comb_weight.append([_par_type[i],_mean_out_weight[i]])
  print '_combination,mean,std',_par_type[i],_mean_out[i],_std_out[i]

_zipped = zip(_use_comb,_use_comb_weight,_frcom)
_zipped.sort(key=lambda x: x[0][1], reverse=True)
#_use_comb.sort(key=lambda _use_comb: _use_comb[1], reverse=True)
_use_comb,_use_comb_weight,_use_fr = map(list,zip(*_zipped)) 

## calculate relative free energy
_diff_list, _num =[], 0
_out = [0.0 for i in range(_max)]

for i in range(2,len(_use_comb)+1, 1):

  _relative_free, _diff,_cluster = solve_linear_eq(_use_comb_weight[:i])
  print 'i,_relative_free, _diff,_cluster', i,_relative_free, _diff,_cluster

  if _diff <=_stop and _diff !=0:
    _num += 1
    _diff_list.append([i,_diff,_cluster[-1]])
  #elif _diff>1.5: break
  #elif _diff >1:break
  elif _diff >_stop:break

print '_diff_list',_diff_list
_use_relative_free, _use_diff,_use_cluster = solve_linear_eq(_use_comb_weight[:_diff_list[-1][0]])
_id = [i-1 for i in _use_cluster]
for _l,_m in enumerate(_id):
  _out[_m] = _use_relative_free[_l]*(-1)

## prob of frame of used combination
probfr = sum(_use_fr[:_diff_list[-1][0]])/_frame_list

## prob of used combination
probcom = np.sum(np.array(_use_comb_weight[:_diff_list[-1][0]])[:,1])

fprob = open(_dir+'%s-prob.xvg'%_nchain,'w')
fprob.write('frame: %f\ntotal frame: %d\n\n'%(probfr,_frame_list))
fprob.write('prob: %f\n'%probcom)
fprob.write('used combination:\n')
for _com in _use_comb_weight[:_diff_list[-1][0]]:
  fprob.write('%s\n'%_com)
fprob.close()

### Calculate mean and error of oligomer distribution
_num1 = np.zeros(_max, dtype=np.float64)
for _e,_r in enumerate(_prop):
  for _l,_m in enumerate(_r):
    if _m >0:
      _num1[_l] += 1
_mean_distri,_err_distri = np.zeros(_max, dtype=np.float64), np.zeros(_max, dtype=np.float64)

for _e in range(_max):
  _sum = np.array(_prop)[:,_e].sum()
  if _sum == 0:
    _mean_distri[_e] = 0.0
    _err_distri[_e] = 0.0
    continue
  else:
    _mean_distri[_e] = _sum/_num1[_e]
  _tmp = 0
  for j in np.array(_prop)[:,_e]:
    _tmp += (j-_mean_distri[_e])*(j-_mean_distri[_e])
  _err_distri[_e] = math.sqrt(_tmp/_num1[_e])


f_ave_err = open(_dir+'%s-relative-free-ene-ave.xvg'%(_nchain),'w')
#f_ave_err.write('oligomer size;  average  ;  error\n')
f_ave_err.write('oligomer size;  average  ;\n')

for _ee in range(_max):
  #f_ave_err.write('%d : %f %f\n'%(_ee+1,_mean[_ee], _err[_ee]))
  f_ave_err.write('%d : %f\n'%(_ee+1,_out[_ee]))

f_ave_err.close()

fo_distri.close()

