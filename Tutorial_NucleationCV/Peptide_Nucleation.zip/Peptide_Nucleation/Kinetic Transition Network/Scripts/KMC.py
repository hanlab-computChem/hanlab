import sys
import numpy
import numpy.random

def show_state(_trj_stat,_c_state,_time):
 if len(_trj_stat)!=len(_c_state) or len(_trj_stat)!=len(_time):
  print 'sth wrong'
  sys.exit()

 for _i in xrange(len(_c_state)):
  print '%d|%d|%f'%(_trj_stat[_i],_c_state[_i],_time[_i]),
 print

#main#

_conn=[]
_conn_v=[]

_cnt = 0
for rl in open(sys.argv[1],'r'):
 srl=rl[:-1].split()
 _i = int(srl[0])
 _j = int(srl[1])
 _v = numpy.exp(float(srl[2]))

 if _i>= _cnt:
  _cnt+=1
  _conn.append([])
  _conn_v.append([])

 _conn[_i].append(_j)
 _conn_v[_i].append(_v)

n_state = len(_conn)

con_cnt = numpy.zeros(n_state, dtype=numpy.int32)
k_t = numpy.zeros(n_state, dtype=numpy.float64)
for _i in xrange(n_state):
 con_cnt[_i] = len(_conn[_i])
 k_t[_i] = sum(_conn_v[_i])

kt_r = numpy.reciprocal(k_t)


max_con = max(con_cnt)

con_mat = -1*numpy.ones((n_state,max_con), dtype=numpy.int32)
cum_k_mat = numpy.zeros((n_state,max_con), dtype=numpy.float64)

for _i in xrange(n_state):
 _kt = k_t[_i]
 _t=0.0
 for _j in xrange(con_cnt[_i]):
  con_mat[_i,_j] = _conn[_i][_j]
  _t+=_conn_v[_i][_j]
  cum_k_mat[_i,_j] = _t/_kt

 cum_k_mat[_i, con_cnt[_i]-1]+=0.0001

#print _conn
#print _conn_v
#print con_mat
#print cum_k_mat
 
n_trj = int(sys.argv[4])
source = int(sys.argv[2])
sink = int(sys.argv[3])

if source<0 or source>=n_state:
 print 'Invalid source id'
 sys.exit()

if sink<0 or sink>=n_state:
 print 'Invalid sink id'
 sys.exit()

if sink==source:
 print 'Sink and source cannot be the same'
 sys.exit()

c_state = source*numpy.ones(n_trj, dtype=numpy.int32)
nxt_state = -1*numpy.ones(n_trj, dtype=numpy.int32)
_time = numpy.zeros(n_trj, dtype=numpy.float64)


_state_end = numpy.zeros(n_trj, dtype = numpy.bool)

# initial RNG

#rng1 = numpy.random.default_rng(seed=42)
#rng2 = numpy.random.default_rng(seed=4233)

_mfpt=0.0

# print trj
_st = 0
_trj_stat= numpy.where(_state_end==False)
while len(_trj_stat[0])>0:
# print c_state
 _sel_n_trj = len(_trj_stat[0])
 _sel_trj_state = c_state[_trj_stat]
 _sel_trj_n_state = nxt_state[_trj_stat]
 _sel_trj_idx = _trj_stat[0]
 _sel_cum_k = cum_k_mat[_sel_trj_state]
 _sel_cum_con = con_mat[_sel_trj_state]
 _sel_kt = k_t[_sel_trj_state]

# print _sel_trj_idx
# print _sel_trj_state

# print _sel_cum_k
 


# generate two list of rn each containing _sel_n_trj rn
# r1, r2
 r1= 1.0-numpy.random.random(_sel_n_trj)
 r2= 1.0-numpy.random.random(_sel_n_trj)
# print r1,r2
# print _sel_trj_n_state
 _mark = numpy.zeros(_sel_n_trj, dtype=numpy.int32)
 for _r in xrange(max_con):
  
  _c_p = _sel_cum_k[:,_r]
  _c_con = _sel_cum_con[:,_r]
#  print _c_p - r1
  _jp = numpy.where(((_c_p-r1)>0.0)&(_mark==0))
 
  _sel_trj_n_state[_jp] = _c_con[_jp]
  _mark[_jp]=1
#  print _r, _jp,_c_p,r1, _c_p-r1, _sel_trj_n_state
#  print _r, _c_p, r1, _c_con 

 c_state[_trj_stat] = _sel_trj_n_state[:]

 

 _time[_trj_stat]+= kt_r[_sel_trj_state]*numpy.log(numpy.reciprocal(r2))

# print trj
 show_state(_trj_stat[0],_sel_trj_n_state,_time[_trj_stat])

 _sel_end = numpy.where(_sel_trj_n_state==sink)

 _mfpt+=_time[_sel_trj_idx[_sel_end]].sum()

 _state_end[_sel_trj_idx[_sel_end]] = True

 _trj_stat= numpy.where(_state_end==False)

 if len(_trj_stat[0])< _sel_n_trj:
  print len(_trj_stat[0]),'trjs left'

# _st+=1

# if _st>3: break

print 'mfpt', _mfpt/n_trj

