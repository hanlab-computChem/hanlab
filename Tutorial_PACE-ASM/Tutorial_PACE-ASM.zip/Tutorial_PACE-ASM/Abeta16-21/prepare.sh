#!/bin/bash
#usage: bash prepare.sh (The name of PDB file) (capped 0/uncapped 1)
#notice: the second column should be atomID and sixth column should be residueID in your PDB file.
#example:
#capped termini prepare usage: bash prepare.sh 2y2a 0
#uncapped termini prepare usage: bash prepare.sh 2y2a 1

if [[ "$2" =~ "1" ]]
then
echo "Uncapped termini"
#modify PDB file
sed -e "/OXT/d" -e "/^HETATM/d" "$1".pdb > "$1"_a.pdb
#pdb2gmx
pdb2gmx -f "$1"_a.pdb -o "$1"-pace.pdb -p draft.top -ff pace-asm -ter -ignh <<EOF
1
0
0
EOF
#renumber residues
python change_resid.py "$1"-pace.pdb > "$1"-pace-resid.pdb || exit 
#genpairpace
count_residue=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $6}') || exit
count_atom=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $2}') || exit
./genPairPACE $count_atom $count_residue "$1"-pace-resid.pdb $2 > "$1".patch || exit
#insert_param.py
python insert_param.py "$1"-pace.patch draft.top > "$1"-pace.top || exit
#modify top file
python C-N-ter.py "$1"-pace-resid.pdb $count_residue "$1"-pace.top > "$1"-pace-ter.top || exit
mv "$1"-pace-ter.top "$1"-pace.top
#rename posre.itp and protein/peptide
mv posre.itp posre_"$1".itp
sed -i "s/posre.itp/posre_"$1".itp/g" "$1"-pace.top
name=$(grep -A2 "moleculetype" "$1"-pace.top | tail -1 | awk '{print $1}')
sed -i "s/"$name"/Protein_"$1"/g" "$1"-pace.top
echo "Successfully prepared uncapped coordinate file and topology file"
fi

if [[ "$2" =~ "0" ]]
then
echo "Capped termini"
#modify PDB file
sed -e "/OXT/d" -e "/^HETATM/d" "$1".pdb > "$1"_a.pdb
python add-cap.py "$1"_a.pdb > "$1"-cap.pdb
#pdb2gmx
pdb2gmx -f "$1"-cap.pdb -o "$1"-pace.pdb -p draft.top -ff pace-asm -ter -ignh <<EOF
1
1
1
EOF
#renumber residues
python change_resid.py "$1"-pace.pdb > "$1"-pace-resid.pdb || exit 
#genpairpace
count_residue=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $6}') || exit
count_atom=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $2}') || exit
./genPairPACE $count_atom $count_residue "$1"-pace-resid.pdb $2 > "$1"-pace.patch || exit
#insert_param.py
python insert_param.py "$1"-pace.patch draft.top > "$1"-pace.top || exit
#NMA->NH2
python pace_genCONH2.py "$1"-pace.top > "$1"-pace-NH2.top || exit
mv "$1"-pace-NH2.top "$1"-pace.top
#modify coordinate file
sed -i "s/N   NMA/N   NH2/g" "$1"-pace-resid.pdb
sed -i "s/H   NMA/H1  NH2/g" "$1"-pace-resid.pdb
sed -i "s/CA  NMA/H2  NH2/g" "$1"-pace-resid.pdb
#rename posre.itp and protein/peptide
mv posre.itp posre_"$1".itp
sed -i "s/posre.itp/posre_"$1".itp/g" "$1"-pace.top
name=$(grep -A2 "moleculetype" "$1"-pace.top | tail -1 | awk '{print $1}')
sed -i "s/"$name"/Protein_"$1"/g" "$1"-pace.top
echo "Successfully prepared capped topology file and coordinate file"
fi
