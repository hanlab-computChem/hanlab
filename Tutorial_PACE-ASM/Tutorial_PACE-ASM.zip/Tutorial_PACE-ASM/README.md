Prerequisites:
The following software is required for modeling protein systems with PACE-ASM:
    1) GROMACS 4.x is required to prepare necessary files for simulation setup. GROMACS 5.x is strongly recommended for actual simulations as this version has gained much improved performance in parallel simulations. The installation guideline of GROMACS is detailed at www.gromacs.org;
    2) Python 2.4 or later is needed. To install Python, please visit www.python.org;
    3) A C compiler is required. A GNU C complier is recommended and will be assumed throughout this tutorial;
    4) VMD, a visualization software, is optional but highly recommended

Installation:
Assuming that a GROMACS 4.x has been installed at /home/xxx/gromacs and you have downloaded Tutorial_PACE-ASM, please follow the steps below to complete the installation:
    1）Copy the folder pace-asm.ff under folder Tutorial_PACE-ASM to the top directory of gromacs-4.x(/home/xxx/gromacs/share/gromacs/top/).
    2）Compile a program called genPairPACE13 which is needed to modify topology files to incorporate PACE parameters:
       cd Tutorial_PACE-ASM/scripts/genpair/
       make
       A binary file called genPairPACE13 should be generated in the same directory;

Getting started for simulations: 
Shown below is a simple example(take Abeta16-21 self-assembly as an example) of how to setup a PACE-ASM simulation starting from PDB:
   1) Download the Abeta16-21 structure (PDB ID: 2Y2A) from website https://www.rcsb.org, and delete the OXT atom of C termini and atoms starting with HETATM.
   2) Construct topology and coordinate files according to the downloaded PDB file:
      command: pdb2gmx -f 2y2a.pdb -o 2y2a-pace.pdb -p draft.top -ter 
      Select PACE-ASM force field and cgWater, and we select charged termini with 0 in this Abeta16-21 case, if the system is capped termini, we select capped termini with 1.
   3) Generate topology files for PACE-ASM. There are three programs called change_chainid.py, genPairPACE13 and insert_param.py in the scripts directory, the first rearrange the sequence number of residues, and the second generating special topology file containing PACE parameters for the system and the last combining the normal topology file (draft.top) and the special topology file to create a topology file for actual simulations. To use genPairPACE13, users first need to find out how many atoms (count_atom) and residues (count_residue) there are in 3GB1-pace.pdb, and then run the program as follows: 
      command: python change_chainid.py 2y2a-pace.pdb > 2y2a-pace-chain.pdb
      command: ./genPairPACE13 count_atom count_residue 2y2a-pace-chain.pdb 1 > 2y2a.patch
      where 2y2a.patch is the special topology file. Please note that there is an option of 0/1 right after the name of a PDB file such as in the current case 2y2a-pace.pdb. This option tells the program the status of protein termini with 1 for charged termini and with 0 for capped ones. Then one can combine 2y2a.patch with draft.top as follows:
      command: python insert_param.py 2y2a.patch draft.top > 2y2a-pace.top
      Finally, if we select the charged termini, a minor change need to be made to the resulting 2y2a-pace.top, simply modifing the force constant of psi dihedral of N termini and add the CMAP to the C termini. If we select the capped termini, we do not need to modify anything.
      N termini: the dihedral angular force constant with N-terminal multiplicity of 1 and initial phase of 0 is changed to 4, in this case: 1     2     8    10     1    -0.0   1.0  1 -->   1     2     8    10     1    -0.0   4.0  1
      C termini: Add two lines before this sentence(; Include Position restraint file), first line is [ cmap ], second line is C(i-1) N(i) CA(i) C(i) O1(i) 1, i is the last residue, in this case, two lines shown below:
      [ cmap ]
      49  51  53  55  56  1
   4) Generate self-assembly topology file and coordinate file.The coordinate file need to be generated with gromacs5.0 or above, and topology file, the topology file only needs to change the last line to 18 molecules. 
      Coordinate file: command: gmx insert-molecules -ci 2y2a-pace-chain.pdb -nmol 18 -box 12 12 12 -o 2y2a_18.gro
      Topology file: Protein_chain_A     1 --> Protein_chain_A     18 
   5) The follow-up operation is the same as the protein simulation operation:
   
      (We suggest an order, by mdp files to be used, as follow to perform simulations: 
      em.mdp ; Minimization
      prnvt.mdp ; NVT pre-equilibration
      pr.mdp ; NPT pre-equilibration
      full330.mdp ; Production run)

      Solvate peptides: 
      command: genbox -cp 2y2a_18.gro -cs cg216water.gro -p 2y2a-pace.top -vdwd 0.235 -o 2y2a-pace-sov.gro
      Ion addition:
      command: grompp -v -f em.mdp -c 2y2a-pace-sov.gro -p 2y2a-pace.top -o 2y2a-em-sov.tpr
      command: genion -s 2y2a-em-sov.tpr -o 2y2a-ion-sov.gro -p 2y2a-pace.top -conc 0.15 -neutral -pname NA -nname CL
      Minimization:
      command: grompp -v -f em.mdp -c 2y2a-ion-sov.gro -p 2y2a-pace.top -o em.tpr
      command: mdrun -s em.tpr -c em.gro
      NVT pre-equilibration:
      command: grompp -v -f prnvt.mdp -c em.gro -p 2y2a-pace.top -o prnvt.tpr
      command: mdrun -s prnvt.tpr -c prnvt.gro
      NPT pre-equilibration:
      command: grompp -v -f pr.mdp -c prnvt.gro -p 2y2a-pace.top -o pr.tpr
      command: mdrun -s pr.tpr -c pr.gro
      Production run:
      command: grompp -v -f full330.mdp -c pr.gro -p 2y2a-pace.top -o full330.tpr
      command: mdrun -deffnm full330 -rdd 1.9 -dds 0.9  
 

