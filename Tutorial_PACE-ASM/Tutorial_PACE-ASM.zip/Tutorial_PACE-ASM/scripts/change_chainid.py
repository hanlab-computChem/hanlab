import sys

f = open(sys.argv[1],'r')
Read = True
for rl in f:
    if rl.startswith("ATOM") and Read:
        Value = int(rl[22:26])-1
        Read = False
    if rl.startswith("ATOM"):
        print rl[:22]+"%4d"%(int(rl[22:26])-Value)+rl[26:-1]
    else:
        print rl[:-1]
