#!/bin/bash
#usage: bash prepare.sh (The name of PDB file) (uncapped 0/capped 1/N-capped 2/C-capped 3)
#notice: the second column should be atomID and sixth column should be residueID in your PDB file.
#example:
#capped termini prepare usage: bash prepare.sh 2y2a 0
#uncapped termini prepare usage: bash prepare.sh 2y2a 1
# genPaiePACE  natom nres name 1/0
# 0 strict mode: all atoms need to be matched with reference structures in internal database
# it will halt if any atom is missing or having wrong name
# it is recommonded to always use mode 0 if possible such as capped peptides
# 1 forgiving mode: it doesnt halt for missing or wrong atoms
# in case of uncapped peptides at any end, terminal residues are always incomplete
# so it must use 1 mode

SDIR="TO_BE_REPLACED"
cp "$SDIR"residuetypes.dat ./
cp "$SDIR"comb_top.py ./
cp MDP_DIR/mdp/* ./

if [[ "$2" =~ "0" ]]
then
echo "Uncapped termini"
#modify PDB file
sed -e "/OXT/d" -e "/^HETATM/d" "$1".pdb > "$1"_a.pdb
#pdb2gmx
gmx pdb2gmx -f "$1"_a.pdb -o "$1"-pace.pdb -p draft.top -ff pace-asm -ter -ignh <<EOF
1
0
0
EOF
#renumber residues
python "$SDIR"change_resid.py "$1"-pace.pdb > "$1"-pace-resid.pdb || exit 
#genpairpace
count_residue=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $6}') || exit
count_atom=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $2}') || exit
"$SDIR"genpair/genPairPACE $count_atom $count_residue "$1"-pace-resid.pdb 1 > "$1"-pace.patch || exit
#insert_param.py
python "$SDIR"insert_param.py "$1"-pace.patch draft.top > "$1"-pace.top || exit
#modify top file
python "$SDIR"C-N-ter.py "$1"-pace-resid.pdb $count_residue "$1"-pace.top both > "$1"-pace-ter.top || exit
#rename posre.itp and protein/peptide
mv posre.itp posre_"$1".itp
python "$SDIR"rpl_posre.py "$1"-pace-ter.top $1 "$1"-pace.top
echo "Successfully prepared uncapped coordinate file and topology file"
fi

if [[ "$2" =~ "1" ]]
then
echo "Capped termini"
#modify PDB file
sed -e "/OXT/d" -e "/^HETATM/d" "$1".pdb > "$1"_a.pdb
python "$SDIR"add-cap.py "$1"_a.pdb both > "$1"-cap.pdb
#pdb2gmx
gmx pdb2gmx -f "$1"-cap.pdb -o "$1"-pace.pdb -p draft.top -ff pace-asm -ter -ignh <<EOF
1
1
1
EOF
#renumber residues
python "$SDIR"change_resid.py "$1"-pace.pdb > "$1"-pace-resid.pdb || exit 
#genpairpace
count_residue=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $6}') || exit
count_atom=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $2}') || exit
"$SDIR"genpair/genPairPACE $count_atom $count_residue "$1"-pace-resid.pdb 0 > "$1"-pace.patch || exit
#insert_param.py
python "$SDIR"insert_param.py "$1"-pace.patch draft.top > "$1"-pace.top || exit
#NMA->NH2
python "$SDIR"pace_genCONH2.py "$1"-pace.top > "$1"-pace-NH2.top || exit
#mv "$1"-pace-NH2.top "$1"-pace.top
#modify coordinate file
sed -e "s/N   NMA/N   NH2/g" -e "s/H   NMA/H1  NH2/g" -e "s/CA  NMA/H2  NH2/g"  "$1"-pace-resid.pdb > "$1"-pace-resid_a.pdb || exit
mv "$1"-pace-resid_a.pdb "$1"-pace-resid.pdb
#rename posre.itp and protein/peptide
mv posre.itp posre_"$1".itp
python "$SDIR"rpl_posre.py "$1"-pace-NH2.top $1 "$1"-pace.top
echo "Successfully prepared capped topology file and coordinate file"
fi

if [[ "$2" =~ "2" ]]
then
echo "N-Capped termini"
#modify PDB file
sed -e "/OXT/d" -e "/^HETATM/d" "$1".pdb > "$1"_a.pdb
python "$SDIR"add-cap.py "$1"_a.pdb Nter > "$1"-Ncap.pdb
#pdb2gmx
gmx pdb2gmx -f "$1"-Ncap.pdb -o "$1"-pace.pdb -p draft.top -ff pace-asm -ter -ignh <<EOF
1
1
0
EOF
#renumber residues
python "$SDIR"change_resid.py "$1"-pace.pdb > "$1"-pace-resid.pdb || exit
#genpairpace
count_residue=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $6}') || exit
count_atom=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $2}') || exit
"$SDIR"genpair/genPairPACE $count_atom $count_residue "$1"-pace-resid.pdb 1 > "$1"-pace.patch || exit
#insert_param.py
python "$SDIR"insert_param.py "$1"-pace.patch draft.top > "$1"-pace.top || exit
#modify top file
python "$SDIR"C-N-ter.py "$1"-pace-resid.pdb $count_residue "$1"-pace.top Cter > "$1"-pace-Ncap.top || exit
#rename posre.itp and protein/peptide
mv posre.itp posre_"$1".itp
python "$SDIR"rpl_posre.py "$1"-pace-Ncap.top $1 "$1"-pace.top
echo "Successfully prepared N-capped topology file and coordinate file"
fi


if [[ "$2" =~ "3" ]]
then
echo "C-Capped termini"
#modify PDB file
sed -e "/OXT/d" -e "/^HETATM/d" "$1".pdb > "$1"_a.pdb
python "$SDIR"add-cap.py "$1"_a.pdb Cter > "$1"-Ccap.pdb
#pdb2gmx
gmx pdb2gmx -f "$1"-Ccap.pdb -o "$1"-pace.pdb -p draft.top -ff pace-asm -ter -ignh <<EOF
1
0
1
EOF
#renumber residues
python "$SDIR"change_resid.py "$1"-pace.pdb > "$1"-pace-resid.pdb || exit
#genpairpace
count_residue=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $6}') || exit
count_atom=$(grep "ATOM" "$1"-pace-resid.pdb | tail -1 | awk '{print $2}') || exit
"$SDIR"genpair/genPairPACE $count_atom $count_residue "$1"-pace-resid.pdb 1 > "$1"-pace.patch || exit
#insert_param.py
python "$SDIR"insert_param.py "$1"-pace.patch draft.top > "$1"-pace.top || exit
#modify top file
python "$SDIR"C-N-ter.py "$1"-pace-resid.pdb $count_residue "$1"-pace.top Nter > "$1"-pace-NMA.top || exit
python "$SDIR"pace_genCONH2.py "$1"-pace-NMA.top > "$1"-pace-NH2.top || exit
#modify coordinate file
sed -e "s/N   NMA/N   NH2/g" -e "s/H   NMA/H1  NH2/g" -e "s/CA  NMA/H2  NH2/g"  "$1"-pace-resid.pdb > "$1"-pace-resid_a.pdb || exit
mv "$1"-pace-resid_a.pdb "$1"-pace-resid.pdb
#rename posre.itp and protein/peptide
mv posre.itp posre_"$1".itp
python "$SDIR"rpl_posre.py "$1"-pace-NH2.top $1 "$1"-pace.top
echo "Successfully prepared C-capped topology file and coordinate file"
fi

